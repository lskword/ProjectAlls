observer.regist('openUserLayer', function () {
	console.log()
})